﻿using System.ComponentModel.DataAnnotations;

namespace Zad4.Models
{
    public class ExerciseType
    {
        public int Id { get; set; }
        [Display(Name="Nazwa ćwiczenia")]
        [MaxLength(50)]
        public string Name { get; set; }
    }
}
