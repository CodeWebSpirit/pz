﻿using System.ComponentModel.DataAnnotations;

namespace Zad4.Models
{
    public class Exercise
    {
        public int Id { get; set; }
        [Display(Name="Waga")]
        [Range(1, 500, ErrorMessage = "Waga musi wynosić od 1 do 500")]
        public int Weight { get; set; }
        [Display(Name = "Ilość serii")]
        [Range(1, 30, ErrorMessage = "Ilość serii nie może być większa niż 30")]
        public int NumOfSeries { get; set; }
        [Display(Name = "Ilość powtórzeń")]
        [Range(1, 100, ErrorMessage = "Ilość powtórzeń nie może być większa niż 100")]
        public int NumOfReps { get; set; }
        [Display(Name = "Typ ćwiczenia")]
        public int ExerciseTypeId { get; set; }
        public virtual ExerciseType? ExerciseType { get; set; }
        [Display(Name = "Początek sesji")]
        public int SessionId { get; set; }
        public virtual Session? Session { get; set; }
    }
}
