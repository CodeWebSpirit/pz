﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace Zad4.Models
{
    public class Session
    {
        public int Id { get; set; }
        [Display(Name = "Początek sesji")]
        public DateTime Start {  get; set; }
        [Display(Name = "Koniec sesji")]
        public DateTime End { get; set; }
        public string? UserId { get; set; }
        public IdentityUser? User { get; set; }
    }
}
