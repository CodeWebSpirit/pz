﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Zad4.Models;

namespace Zad4.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Zad4.Models.ExerciseType> ExerciseType { get; set; } = default!;
        public DbSet<Zad4.Models.Session> Session { get; set; } = default!;
        public DbSet<Zad4.Models.Exercise> Exercise { get; set; } = default!;
    }
}
